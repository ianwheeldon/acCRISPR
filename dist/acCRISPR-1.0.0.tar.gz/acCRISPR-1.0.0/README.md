## acCRISPR: an activity-correction method for improving CRISPR screen accuracy

For details on usage and installation, visit https://github.com/ianwheeldon/acCRISPR.
