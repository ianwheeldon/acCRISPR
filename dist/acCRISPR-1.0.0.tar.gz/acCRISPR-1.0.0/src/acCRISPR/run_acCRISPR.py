#!/usr/bin/env python3

from ac_CRISPR import run_ac_CRISPR

if __name__ == '__main__':
    run_ac_CRISPR()
